package cassandredis

import (
	"fmt"
	"strings"
)

// Query is a CQL statement with its args
type Query struct {
	Stmt string
	Args []interface{}
}

func makeQuery(stmt string, args ...interface{}) *Query {
	return &Query{
		Stmt: stmt,
		Args: args,
	}
}

func (q *Query) String() string {
	stmt := strings.Replace(q.Stmt, "\n", "", -1)
	return fmt.Sprintf("stmt: %s args: %v", stmt, q.Args)
}

type Queries []*Query
