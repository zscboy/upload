package cassandredis

import (
	"bytes"
	"errors"
	"fmt"
	"log"
	"strconv"

	"github.com/gocql/gocql"
)

func (p *proxy) preLRANGE(req *Command, session *proxySession) {
	if len(req.Args) < 3 {
		session.err = errors.New("syntax error on LRANGE, need at least 3 arguments")
	}

	session.currentKey = newQueryKeyFromString(req.Args[0].(*respBulkStringValue).String())
}

func (p *proxy) processLRANGE(req *Command, session *proxySession) {
	// TODO(vincent): handle relative offsets
	start, stop, err := getRangeStartStop(req.Args[1:])
	if err != nil {
		session.err = err
		return
	}

	first, last, err := p.getListsMatchingUUIDs(session.currentKey, start, stop)
	if err != nil {
		session.err = err
		return
	}

	if len(session.currentKey.pk) > 0 {
		p.processLRANGEWithPk(req, session, first, last)
		return
	}

	q := makeLRANGEQuery(session.currentKey, first, last)
	p.readAndSendListValues(q, session)
}

func (p *proxy) getListsMatchingUUIDs(key queryKey, start, stop int64) (first *gocql.UUID, last *gocql.UUID, err error) {
	q := "SELECT uuid_val FROM lists_indexes WHERE table_name = ? AND list_index = ?"

	log.Printf("executing query %s", makeQuery(q, key.metadataKey(), start))
	it := p.session.Query(q, key.metadataKey(), start).Iter()
	it.Scan(&first)
	if err = it.Close(); err != nil {
		return
	}

	log.Printf("executing query %s", makeQuery(q, key.metadataKey(), stop))
	it = p.session.Query(q, key.metadataKey(), stop).Iter()
	it.Scan(&last)
	err = it.Close()

	return
}

func (p *proxy) processLRANGEWithPk(req *Command, session *proxySession, first, last *gocql.UUID) {
	q := makeLRANGEWithPkQuery(session.currentKey, first, last)
	p.readAndSendListValues(q, session)
}

func (p *proxy) readAndSendListValues(q *Query, session *proxySession) {
	if q == nil {
		sendArrayResponse(session, nil)
		return
	}

	log.Printf("executing query %s", q)
	it := p.session.Query(q.Stmt, q.Args...).Iter()

	var values [][]byte
	var value []byte
	for it.Scan(&value) {
		values = append(values, value)
	}

	if err := it.Close(); err != nil {
		session.err = err
		return
	}

	sendArrayResponse(session, values)
}

func makeLRANGEQuery(key queryKey, first, last *gocql.UUID) *Query {
	var buf bytes.Buffer
	fmt.Fprintf(&buf, "SELECT value FROM %s WHERE bucket = 0", key.namespace)

	var args []interface{}

	if first != nil {
		buf.WriteString(" AND tuuid >= ?")
		args = append(args, first)
		if last != nil {
			buf.WriteString(" AND tuuid < ?")
			args = append(args, last)
		}
	} else {
		return nil
	}

	return &Query{
		Stmt: buf.String(),
		Args: args,
	}
}

func makeLRANGEWithPkQuery(key queryKey, first, last *gocql.UUID) *Query {
	var buf bytes.Buffer

	fmt.Fprintf(&buf, "SELECT value FROM %s", key.namespace)
	for i := range key.pk {
		if i == 0 {
			buf.WriteString(" WHERE ")
		} else {
			buf.WriteString(" AND ")
		}
		fmt.Fprintf(&buf, "f%d = ?", i)
	}

	var args []interface{}
	for _, v := range key.pk {
		args = append(args, v)
	}

	if first != nil {
		buf.WriteString(" AND tuuid >= ?")
		args = append(args, *first)

		if last != nil {
			buf.WriteString(" AND tuuid < ?")
			args = append(args, *last)
		}
	} else {
		return nil
	}

	return makeQuery(buf.String(), args...)
}

func getRangeStartStop(args []interface{}) (int64, int64, error) {
	v1 := args[0].(*respBulkStringValue).String()
	v2 := args[1].(*respBulkStringValue).String()

	i1, err := strconv.ParseInt(v1, 10, 64)
	if err != nil {
		return -1, -1, err
	}

	i2, err := strconv.ParseInt(v2, 10, 64)
	if err != nil {
		return -1, -1, err
	}

	return i1, i2, nil
}
