package cassandredis

import (
	"errors"
	"fmt"
	"log"
	"net"
	"strings"
	"sync"

	"github.com/gocql/gocql"
)

type proxySession struct {
	client net.Conn
	req    chan *Command
	resp   chan *respValue
	err    error

	// currentQueries Queries
	currentKey queryKey
	scratch    interface{}
}

type proxy struct {
	hosts    []string
	session  *gocql.Session
	sessions []*proxySession
	md       *metadata

	mu       sync.RWMutex
	ddlState map[string]bool
}

func newProxy(hosts, keyspace string) (*proxy, error) {
	realHosts := strings.Split(hosts, ",")
	if len(hosts) < 1 {
		return nil, errors.New("no cassandra hosts defined")
	}

	cluster := gocql.NewCluster(realHosts...)
	cluster.ProtoVersion = 2
	cluster.Keyspace = keyspace

	session, err := cluster.CreateSession()
	if err != nil {
		return nil, err
	}

	return &proxy{
		hosts:    realHosts,
		session:  session,
		md:       newMetadata(),
		ddlState: make(map[string]bool),
	}, nil
}

func (p *proxy) addSession(session *proxySession) {
	p.sessions = append(p.sessions, session)

	go p.listen(session)
}

func (p *proxy) listen(session *proxySession) {
	for {
		session.err = nil
		req := <-session.req

		p.pre(req, session)
		p.ddl(req, session)
		p.process(req, session)

		if session.err != nil {
			log.Println(session.err)
			sendErrorResponse(session, session.err)
		}
	}
}

func (p *proxy) pre(req *Command, session *proxySession) {
	switch req.Type {
	case CommandLPUSH:
		p.preLPUSH(req, session)
	case CommandLRANGE:
		p.preLRANGE(req, session)
	case CommandSET:
		p.preSET(req, session)
	case CommandGET:
		p.preGET(req, session)
	default:
		session.err = fmt.Errorf("command %s not supported", req.Name)
	}
}

func (p *proxy) ddl(req *Command, session *proxySession) {
	if session.err != nil {
		return
	}

	var queries Queries

	switch req.Type {
	case CommandLPUSH:
		queries, session.err = p.ddlMapLPUSH(req, session)
	case CommandSET:
		queries, session.err = p.ddlMapSET(req, session)
	}

	if session.err != nil {
		return
	}

	for _, v := range queries {
		p.mu.RLock()
		tmp, ok := p.ddlState[v.Stmt]
		run := !ok || !tmp
		p.mu.RUnlock()

		if run {
			log.Printf("executing DDL query: %s", v)
			if session.err = p.session.Query(v.Stmt, v.Args).Exec(); session.err != nil {
				return
			}

			p.mu.Lock()
			p.ddlState[v.Stmt] = true
			p.mu.Unlock()
		}
	}

	return
}

func (p *proxy) process(req *Command, session *proxySession) {
	if session.err != nil {
		return
	}

	switch req.Type {
	case CommandLPUSH:
		p.processLPUSH(req, session)
	case CommandLRANGE:
		p.processLRANGE(req, session)
	case CommandSET:
		p.processSET(req, session)
	case CommandGET:
		p.processGET(req, session)
	}
}

func sendSimpleStringResponse(session *proxySession, value string) {
	resp := &respSimpleStringValue{value}
	session.resp <- &respValue{respSimpleString, resp}
}

func sendArrayResponse(session *proxySession, values [][]byte) {
	resp := &respArrayValue{
		length: len(values),
	}
	for _, v := range values {
		r := &respBulkStringValue{v}
		resp.values = append(resp.values, r)
	}

	session.resp <- &respValue{respArray, resp}
}

func sendBulkStringResponse(session *proxySession, value []byte) {
	resp := &respBulkStringValue{value: value}
	session.resp <- &respValue{respBulkString, resp}
}

func sendNullBulkStringResponse(session *proxySession) {
	sendBulkStringResponse(session, nil)
}

func sendIntegerResponse(session *proxySession, val int64) {
	resp := &respIntegerValue{value: val}
	session.resp <- &respValue{respInteger, resp}
}

func sendErrorResponse(session *proxySession, err error, args ...interface{}) {
	resp := &respErrorValue{message: err.Error()}
	session.resp <- &respValue{respError, resp}
}

func makeProxySession(conn net.Conn) *proxySession {
	return &proxySession{
		client: conn,
		req:    make(chan *Command),
		resp:   make(chan *respValue),
	}
}
