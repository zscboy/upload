package cassandredis

import (
	"bytes"
	"errors"
	"fmt"
	"log"
)

func (p *proxy) preSET(req *Command, session *proxySession) {
	if len(req.Args) < 2 {
		session.err = errors.New("syntax error on SET")
		return
	}

	session.currentKey = newQueryKeyFromString(req.Args[0].(*respBulkStringValue).String())
}

func (p *proxy) ddlMapSET(req *Command, session *proxySession) (Queries, error) {
	if len(req.Args) < 2 {
		return nil, errors.New("syntax error on SET, need at least two arguments")
	}

	if len(session.currentKey.pk) > 0 {
		return ddlMapSETWithPK(session.currentKey)
	}

	q := `CREATE TABLE IF NOT EXISTS %s(
        key blob PRIMARY KEY,
        value blob)`
	q = fmt.Sprintf(q, session.currentKey.namespace)

	return Queries{makeQuery(q)}, nil
}

func ddlMapSETWithPK(key queryKey) (Queries, error) {
	var buf bytes.Buffer
	{
		fmt.Fprintf(&buf, "CREATE TABLE IF NOT EXISTS %s(", key.namespace)
		for i := range key.pk {
			fmt.Fprintf(&buf, "f%d text, ", i)
		}
		buf.WriteString("value blob, PRIMARY KEY ((")
		for i := range key.pk {
			if i > 0 {
				buf.WriteString(", ")
			}
			fmt.Fprintf(&buf, "f%d", i)
		}
		buf.WriteString(")));")
	}

	return Queries{makeQuery(buf.String())}, nil
}

func (p *proxy) processSET(req *Command, session *proxySession) {
	queries, err := p.mapSET(req, session)
	if err != nil {
		session.err = err
		return
	}

	for _, query := range queries {
		log.Printf("executing DML query %s", query)

		q := p.session.Query(query.Stmt, query.Args...)
		if err := q.Exec(); err != nil {
			log.Println(err)
			sendErrorResponse(session, err)
			return
		}
	}

	sendSimpleStringResponse(session, "OK")
}

func (p *proxy) mapSET(req *Command, session *proxySession) (Queries, error) {
	value := req.Args[1].(*respBulkStringValue).value

	if len(session.currentKey.pk) > 0 {
		return p.mapSETWithPK(req, session, value)
	}

	stmt := `INSERT INTO ` + session.currentKey.namespace + `(key, value)
             VALUES (?, ?)`

	return Queries{makeQuery(stmt, session.currentKey.metadataKey(), value)}, nil
}

func (p *proxy) mapSETWithPK(req *Command, session *proxySession, value interface{}) (Queries, error) {
	var buf bytes.Buffer
	{
		buf.WriteString("INSERT INTO ")
		buf.WriteString(session.currentKey.namespace)
		buf.WriteRune('(')
		for i := range session.currentKey.pk {
			fmt.Fprintf(&buf, "f%d, ", i)
		}
		buf.WriteString("value) VALUES(")
		for i, v := range session.currentKey.pk {
			if i > 0 {
				buf.WriteString(", ")
			}
			buf.WriteRune('\'')
			buf.WriteString(v)
			buf.WriteRune('\'')
		}
		buf.WriteString(", ?)")
	}

	return Queries{makeQuery(buf.String(), value)}, nil
}
