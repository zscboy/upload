#!/bin/bash

docker run -d --name cassandra -p 9042:9042 vrischmann/cassandra
