package cassandredis

import (
	"bytes"
	"errors"
	"fmt"
)

func (p *proxy) preGET(req *Command, session *proxySession) {
	if len(req.Args) < 1 {
		session.err = errors.New("syntax error on GET")
		return
	}

	session.currentKey = newQueryKeyFromString(req.Args[0].(*respBulkStringValue).String())
}

func (p *proxy) processGET(req *Command, session *proxySession) {
	query, err := p.mapGET(req, session)
	if err != nil {
		session.err = err
		return
	}

	it := p.session.Query(query.Stmt, query.Args...).Iter()

	var value []byte
	if !it.Scan(&value) {
		sendNullBulkStringResponse(session)
		return
	}

	sendBulkStringResponse(session, value)
}

func (p *proxy) mapGET(req *Command, session *proxySession) (*Query, error) {
	if len(session.currentKey.pk) > 0 {
		return p.mapGETWithPK(req, session)
	}

	stmt := `SELECT value FROM ` + session.currentKey.namespace + `
             WHERE key = ?`

	return makeQuery(stmt, session.currentKey.metadataKey()), nil
}

func (p *proxy) mapGETWithPK(req *Command, session *proxySession) (*Query, error) {
	var buf bytes.Buffer
	var args []interface{}
	{
		fmt.Fprintf(&buf, "SELECT value FROM %s", session.currentKey.namespace)
		for i := range session.currentKey.pk {
			if i == 0 {
				buf.WriteString(" WHERE ")
			} else {
				buf.WriteString(" AND ")
			}
			fmt.Fprintf(&buf, "f%d = ?", i)
		}

		for _, v := range session.currentKey.pk {
			args = append(args, v)
		}
	}

	return makeQuery(buf.String(), args...), nil
}
